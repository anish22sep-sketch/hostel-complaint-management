# Service & Complaint Management System

A college-level Python Flask + SQLite project.

## Features
- User registration and login
- Secure password hashing
- User profile
- Submit complaints
- Complaint category and priority
- Track complaint status
- Admin dashboard
- Admin status updates and notes
- User management
- SQLite database
- Responsive CSS UI

## Requirements
Python 3.10+ recommended.

## Install
```bash
pip install -r requirements.txt
```

## Run
```bash
python app.py
```

Open:
http://127.0.0.1:5000

## Default Admin
Email: admin@gmail.com
Password: admin123

Change the admin password and app secret before using this outside a college/demo environment.

## Database
database.db is created automatically on first run.
