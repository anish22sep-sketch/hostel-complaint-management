from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key"

BASE_DIR = Path(__file__).resolve().parent
DATABASE = BASE_DIR / "database.db"


def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            phone TEXT,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.execute("""
        CREATE TABLE IF NOT EXISTS complaints (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            category TEXT NOT NULL,
            subject TEXT NOT NULL,
            description TEXT NOT NULL,
            priority TEXT NOT NULL DEFAULT 'Medium',
            status TEXT NOT NULL DEFAULT 'Pending',
            admin_note TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

    admin = conn.execute(
        "SELECT id FROM users WHERE email = ?", ("admin@gmail.com",)
    ).fetchone()

    if not admin:
        conn.execute("""
            INSERT INTO users (name, email, phone, password, role)
            VALUES (?, ?, ?, ?, ?)
        """, (
            "Administrator",
            "admin@gmail.com",
            "0000000000",
            generate_password_hash("admin123"),
            "admin"
        ))

    conn.commit()
    conn.close()


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please login first.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Admin access required.", "danger")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not name or not email or not password:
            flash("Please fill all required fields.", "danger")
            return render_template("register.html")

        if password != confirm:
            flash("Passwords do not match.", "danger")
            return render_template("register.html")

        if len(password) < 6:
            flash("Password must contain at least 6 characters.", "danger")
            return render_template("register.html")

        conn = get_db()
        try:
            conn.execute("""
                INSERT INTO users (name, email, phone, password)
                VALUES (?, ?, ?, ?)
            """, (name, email, phone, generate_password_hash(password)))
            conn.commit()
        except sqlite3.IntegrityError:
            conn.close()
            flash("This email is already registered.", "danger")
            return render_template("register.html")

        conn.close()
        flash("Registration successful. Please login.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        conn = get_db()
        user = conn.execute(
            "SELECT * FROM users WHERE email = ?", (email,)
        ).fetchone()
        conn.close()

        if user and check_password_hash(user["password"], password):
            session["user_id"] = user["id"]
            session["name"] = user["name"]
            session["role"] = user["role"]
            session["email"] = user["email"]

            if user["role"] == "admin":
                return redirect(url_for("admin"))
            return redirect(url_for("dashboard"))

        flash("Invalid email or password.", "danger")

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("index"))


@app.route("/dashboard")
@login_required
def dashboard():
    if session.get("role") == "admin":
        return redirect(url_for("admin"))

    conn = get_db()
    complaints = conn.execute("""
        SELECT * FROM complaints
        WHERE user_id = ?
        ORDER BY id DESC
    """, (session["user_id"],)).fetchall()
    conn.close()

    return render_template("dashboard.html", complaints=complaints)


@app.route("/complaint", methods=["GET", "POST"])
@login_required
def complaint():
    if session.get("role") == "admin":
        return redirect(url_for("admin"))

    if request.method == "POST":
        category = request.form.get("category", "").strip()
        subject = request.form.get("subject", "").strip()
        description = request.form.get("description", "").strip()
        priority = request.form.get("priority", "Medium")

        if not category or not subject or not description:
            flash("Please fill all complaint fields.", "danger")
            return render_template("complaint.html")

        if priority not in ("Low", "Medium", "High"):
            priority = "Medium"

        conn = get_db()
        conn.execute("""
            INSERT INTO complaints
            (user_id, category, subject, description, priority)
            VALUES (?, ?, ?, ?, ?)
        """, (
            session["user_id"], category, subject, description, priority
        ))
        conn.commit()
        conn.close()

        flash("Complaint submitted successfully.", "success")
        return redirect(url_for("dashboard"))

    return render_template("complaint.html")


@app.route("/delete_complaint/<int:id>", methods=["POST"])
@login_required
def delete_complaint(id):
    conn = get_db()
    complaint_row = conn.execute("""
        SELECT id FROM complaints
        WHERE id = ? AND user_id = ?
    """, (id, session["user_id"])).fetchone()

    if complaint_row:
        conn.execute("DELETE FROM complaints WHERE id = ?", (id,))
        conn.commit()
        flash("Complaint deleted.", "success")
    else:
        flash("Complaint not found.", "danger")

    conn.close()
    return redirect(url_for("dashboard"))


@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    conn = get_db()

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()

        if not name:
            flash("Name cannot be empty.", "danger")
        else:
            conn.execute("""
                UPDATE users SET name = ?, phone = ?
                WHERE id = ?
            """, (name, phone, session["user_id"]))
            conn.commit()
            session["name"] = name
            flash("Profile updated successfully.", "success")

    user = conn.execute(
        "SELECT id, name, email, phone, role, created_at FROM users WHERE id = ?",
        (session["user_id"],)
    ).fetchone()
    conn.close()

    return render_template("profile.html", user=user)


@app.route("/admin")
@admin_required
def admin():
    conn = get_db()

    complaints = conn.execute("""
        SELECT complaints.*, users.name, users.email, users.phone
        FROM complaints
        JOIN users ON complaints.user_id = users.id
        ORDER BY complaints.id DESC
    """).fetchall()

    total = conn.execute(
        "SELECT COUNT(*) AS c FROM complaints"
    ).fetchone()["c"]
    pending = conn.execute(
        "SELECT COUNT(*) AS c FROM complaints WHERE status = 'Pending'"
    ).fetchone()["c"]
    progress = conn.execute(
        "SELECT COUNT(*) AS c FROM complaints WHERE status = 'In Progress'"
    ).fetchone()["c"]
    resolved = conn.execute(
        "SELECT COUNT(*) AS c FROM complaints WHERE status = 'Resolved'"
    ).fetchone()["c"]

    users = conn.execute("""
        SELECT id, name, email, phone, created_at
        FROM users
        WHERE role = 'user'
        ORDER BY id DESC
    """).fetchall()

    conn.close()

    return render_template(
        "admin.html",
        complaints=complaints,
        total=total,
        pending=pending,
        progress=progress,
        resolved=resolved,
        users=users
    )


@app.route("/update_status/<int:id>", methods=["POST"])
@admin_required
def update_status(id):
    status = request.form.get("status", "Pending")
    note = request.form.get("admin_note", "").strip()

    if status not in ("Pending", "In Progress", "Resolved"):
        status = "Pending"

    conn = get_db()
    conn.execute("""
        UPDATE complaints
        SET status = ?, admin_note = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    """, (status, note, id))
    conn.commit()
    conn.close()

    flash("Complaint updated successfully.", "success")
    return redirect(url_for("admin"))


@app.route("/admin/delete/<int:id>", methods=["POST"])
@admin_required
def admin_delete(id):
    conn = get_db()
    conn.execute("DELETE FROM complaints WHERE id = ?", (id,))
    conn.commit()
    conn.close()

    flash("Complaint deleted.", "success")
    return redirect(url_for("admin"))


@app.route("/admin/users")
@admin_required
def admin_users():
    conn = get_db()
    users = conn.execute("""
        SELECT id, name, email, phone, created_at
        FROM users
        WHERE role = 'user'
        ORDER BY id DESC
    """).fetchall()
    conn.close()
    return render_template("users.html", users=users)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
